package com.adamparys.servicejobmanager.data.model

import android.location.Address
import java.util.*



/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object JobContent {

    /**
     * An array of sample (dummy) jobs.
     */
    val ITEMS: MutableList<JobItem> = ArrayList()

    /**
     * A map of sample (dummy) items, by ID.
     */
    val ITEM_MAP: MutableMap<String, JobItem> = HashMap()

    private const val COUNT = 25

    init {
        // Add some sample items.
        for (i in 1..COUNT) {
            addItem(createDummyItem(i))
        }
    }

    private fun addItem(item: JobItem) {
        ITEMS.add(item)
        ITEM_MAP[item.id!!] = item
    }

    private fun createDummyItem(position: Int): JobItem {
        //Generate a date for Jan. 9, 2013, 10:11:12 AM
        val cal = Calendar.getInstance()
        cal.set(2013, Calendar.JANUARY, 9, 10, 0, 0) //Year, month, day of month, hours, minutes and seconds
        val arrivalWindowBegin = cal.time
        cal.add(Calendar.HOUR, 3)
        val arrivalWindowEnd = cal.time

        val address = Address(Locale.US)
        address.setAddressLine(0, "214-05 15th ave")
        address.postalCode = "11360";
        address.subAdminArea = "Bayside"
        address.adminArea = "NY"

        return JobItem(
            "Adam", "AP Fitness", address, "718-600-2965",
            "service", "", "1234", position.toString(), JobContent.JobStatus.NotStarted,
            arrivalWindowBegin, arrivalWindowEnd, arrivalWindowBegin, null, null
        )
    }

    private fun makeDetails(position: Int): String {
        val builder = StringBuilder()
        builder.append("Details about Item: ").append(position)
        for (i in 0 until position - 1) {
            builder.append("\nMore details information here.")
        }
        return builder.toString()
    }

    /**
     * A dummy item representing a piece of content.
     */
    enum class JobStatus {
        NotStarted,
        Canceled,
        Completed,
        FurtherActionRequired,
        InProgress
    }
    val StatusDescription = mapOf(
        JobStatus.NotStarted to "Not Started",
        JobStatus.Canceled to "Canceled",
        JobStatus.Completed to "Completed",
        JobStatus.FurtherActionRequired to "Further action required",
        JobStatus.InProgress to "In progress")

    data class JobItem(

        var customerName: String? ,
        var companyName: String?,
        var address: Address?,
        var phoneNumber: String?,
        var jobType: String? ,
        var info: String? ,
        var orderNumber: String? ,
        var id: String?,
        var status: JobStatus?,
        var arrivalWindowBegin: Date?,
        var arrivalWindowEnd: Date?,
        var eta: Date?,
        var timeStarted: Date?,
        var timeEnded: Date?
    ) {
        fun copy(copy: JobContent.JobItem?) {
            customerName = copy?.customerName
            companyName = copy?.companyName
            address = copy?.address
            phoneNumber = copy?.phoneNumber
            jobType = copy?.jobType
            info = copy?.info
            orderNumber = copy?.orderNumber
            id = copy?.id
            status = copy?.status
            arrivalWindowBegin = copy?.arrivalWindowBegin
            arrivalWindowEnd = copy?.arrivalWindowEnd
            eta = copy?.eta
            timeStarted = copy?.timeStarted
            timeEnded = copy?.timeEnded

        }

        constructor(copy: JobContent.JobItem?) : this(
            copy?.customerName,
            copy?.companyName,
            copy?.address,
            copy?.phoneNumber,
            copy?.jobType,
            copy?.info,
            copy?.orderNumber,
            copy?.id,
            copy?.status,
            copy?.arrivalWindowBegin,
            copy?.arrivalWindowEnd,
            copy?.eta,
            copy?.timeStarted,
            copy?.timeEnded
        )
    }
}