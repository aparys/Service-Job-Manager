package com.adamparys.servicejobmanager.data

import com.parse.*
import android.app.Application
import com.parse.coroutines.user.parseLogIn

class App : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}