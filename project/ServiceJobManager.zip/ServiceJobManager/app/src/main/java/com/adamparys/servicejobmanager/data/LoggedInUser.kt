package com.adamparys.servicejobmanager.data

class LoggedInUser(toString: String, s: String) {

}
