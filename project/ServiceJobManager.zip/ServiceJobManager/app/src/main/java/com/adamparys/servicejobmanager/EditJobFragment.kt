package com.adamparys.servicejobmanager

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.adamparys.servicejobmanager.data.model.JobContent
import kotlinx.android.synthetic.main.activity_job_detail.*
import java.util.*
import android.app.TimePickerDialog
import kotlinx.android.synthetic.main.fragment_edit_job.view.*
import java.text.SimpleDateFormat
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.fragment_edit_job.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [EditJobFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [EditJobFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class EditJobFragment : Fragment() {

    private var oldItem: JobContent.JobItem? = null
    private var newItem: JobContent.JobItem? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            if (it.containsKey(ARG_ITEM_ID)) {
                // Load the dummy content specified by the fragment
                // arguments. In a real-world scenario, use a Loader
                // to load content from a content provider.
                oldItem = JobContent.ITEM_MAP[it.getString(ARG_ITEM_ID)]
                newItem = JobContent.JobItem(oldItem)
                activity?.toolbar_layout?.title = "Job Details"
            }
        }
    }

     private fun addButtonClickListener(rootView: View) {


         rootView.selectDateButton.setOnClickListener{v->
             val datePick = DatePickerDialog.OnDateSetListener{view, year, month, dayOfMonth ->
                 val cal = Calendar.getInstance()
                 cal.time = newItem?.arrivalWindowBegin
                 cal.set(Calendar.YEAR,year)
                 cal.set(Calendar.MONTH,month)
                 cal.set(Calendar.DAY_OF_MONTH,dayOfMonth)
                 newItem?.arrivalWindowBegin = cal.time
                 var pattern = "MMM d, yyyy"
                 val simpleDateFormat = SimpleDateFormat(pattern, Locale("en", "US"))
                 rootView.selectDateButton.text = simpleDateFormat.format(cal.time)
             }
             val cal = Calendar.getInstance()
             cal.time = newItem?.arrivalWindowBegin
             DatePickerDialog(v.context,datePick,cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
         }

         val latestTimePickerListener = TimePickerDialog.OnTimeSetListener { view, hourOfDay, minutes ->
             val cal = Calendar.getInstance()
             cal.time = newItem?.arrivalWindowEnd
             cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
             cal.set(Calendar.MINUTE, minutes)
             newItem?.arrivalWindowEnd = cal.time
             var pattern = "h:mm a"
             val simpleDateFormat = SimpleDateFormat(pattern, Locale("en", "US"))
             rootView.latestArrivalButton.text = simpleDateFormat.format(oldItem?.arrivalWindowEnd)
         }
         val etaTimePickerListener = TimePickerDialog.OnTimeSetListener { view, hourOfDay, minutes ->
             val cal = Calendar.getInstance()
             cal.time = newItem?.eta
             cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
             cal.set(Calendar.MINUTE, minutes)
             newItem?.eta = cal.time
             var pattern = "h:mm a"
             val simpleDateFormat = SimpleDateFormat(pattern, Locale("en", "US"))
             rootView.etaButton.text = simpleDateFormat.format(newItem?.eta)
         }
         val earliestTimePickerListener = TimePickerDialog.OnTimeSetListener { view, hourOfDay, minutes ->
             val cal = Calendar.getInstance()
             cal.time = newItem?.arrivalWindowBegin
             cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
             cal.set(Calendar.MINUTE, minutes)
             newItem?.arrivalWindowBegin = cal.time
             var pattern = "h:mm a"
             val simpleDateFormat = SimpleDateFormat(pattern, Locale("en", "US"))
             rootView.earliestArrivalButton.text = simpleDateFormat.format(newItem?.arrivalWindowBegin)
         }

         val earliestOnClickListener = View.OnClickListener {
             val cal = Calendar.getInstance()
             cal.time = newItem?.arrivalWindowBegin
             TimePickerDialog(context, earliestTimePickerListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
         }
         val latestOnClickListener = View.OnClickListener {
             val cal = Calendar.getInstance()
             cal.time = newItem?.arrivalWindowEnd
             TimePickerDialog(context, latestTimePickerListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
         }
         val etaOnClickListener = View.OnClickListener {
             val cal = Calendar.getInstance()
             cal.time = newItem?.eta
             TimePickerDialog(context, etaTimePickerListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
         }
         rootView.earliestArrivalButton.setOnClickListener(earliestOnClickListener)
         rootView.latestArrivalButton.setOnClickListener(latestOnClickListener)
         rootView.etaButton.setOnClickListener(etaOnClickListener)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_edit_job, container, false)
        addButtonClickListener(rootView)
        populateFields(rootView,oldItem)
        return rootView
    }


    fun saveChanges() {
        newItem?.companyName =clientCompanyEditText.text.toString()
        newItem?.customerName = customerEditText.text.toString()
        newItem?.status = JobContent.JobStatus.values()[StatusSpinner.selectedItemPosition]
        newItem?.address?.setAddressLine(0,streetEditText.text.toString())
        newItem?.address?.subAdminArea = cityEditText.text.toString()
        newItem?.address?.adminArea = stateEditText.text.toString()
        newItem?.address?.postalCode = zipEditText.text.toString()
        newItem?.phoneNumber = phoneNumberEditText.text.toString()
        oldItem?.orderNumber = orderNumberTextView.text.toString()


            oldItem?.copy(newItem)
    }

    private fun populateFields(
        rootView: View,
        oldItem: JobContent.JobItem?
    ) {
        oldItem?.let {
            var pattern = "MMM d, yyyy"
            val simpleDateFormat = SimpleDateFormat(pattern, Locale("en", "US"))
            val date = simpleDateFormat.format(it.arrivalWindowBegin)
            //formats the time
            pattern = "h:mm a"
            simpleDateFormat.applyPattern(pattern)
            val windowOfArrival = simpleDateFormat.format(it.arrivalWindowBegin) +
                    " - " + simpleDateFormat.format(it.arrivalWindowEnd)
            //formats the address
            rootView.streetEditText.setText(it.address?.getAddressLine(0))
            rootView.cityEditText.setText(it.address?.subAdminArea)
            rootView.stateEditText.setText(it.address?.adminArea)
            rootView.zipEditText.setText(it.address?.postalCode)

            var statusArray = (JobContent.StatusDescription.values).toTypedArray()
            val adapter =
                ArrayAdapter(rootView.context, android.R.layout.simple_spinner_item, statusArray)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            rootView.StatusSpinner.adapter = adapter

            rootView.earliestArrivalButton.text =
                simpleDateFormat.format(it.arrivalWindowBegin)
            rootView.latestArrivalButton.text = simpleDateFormat.format(it.arrivalWindowEnd)
            rootView.etaButton.text = simpleDateFormat.format(it.eta)
            rootView.clientCompanyEditText.setText(it.companyName)
            rootView.customerEditText.setText(it.customerName)
            if (it.status != null)
                rootView.StatusSpinner.setSelection(it.status?.ordinal!!)
            else
                rootView.StatusSpinner.setSelection(0)

            rootView.selectDateButton.text = date
            rootView.orderEditText.setText(it.orderNumber)
            rootView.phoneNumberEditText.setText(it.phoneNumber)

        }    }

    fun cancelChanges() {
        populateFields(view!!.rootView,oldItem)
    }

    companion object {
        /**
         * The fragment argument representing the item ID that this fragment
         * represents.
         */
        const val ARG_ITEM_ID = "item_id"
    }
}